# -*- coding: utf-8 -*-



from . import wizards
from . import hr
from . import report
from . import attendance
from . import payroll
from . import job
from . import holidays
from . import models
 
