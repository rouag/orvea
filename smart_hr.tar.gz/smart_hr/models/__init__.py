# -*- coding: utf-8 -*-


from . import hr
from . import salary_grid
from . import hr_decision_appoint
from . import hr_promotion
from . import hr_training
from . import medical
from . import res_partner
from . import judicial_precedent
from . import recruiter

from . import hr_holidays
from . import hr_holidays_cancellation
from . import hr_overtime
from . import hr_holidays_decision

from . import hr_assessment
from . import hr_assessment_point


from . import res_city
from . import hr_period_line
from . import hr_deputation

from . import hr_suspension
from . import hr_suspension_end

from . import hr_termination

from . import hr_decision

from . import section
from . import hierarchy_level

from . import external_authorities
from . import hr_holidays_extension

from . import religion

from . import courses_follow_up
from . import hr_improve_situation
