# -*- coding: utf-8 -*-

from . import wizard_job_grade
from . import wizard_job_update
from . import wizard_job_description
from . import wizard_job_move_dep
