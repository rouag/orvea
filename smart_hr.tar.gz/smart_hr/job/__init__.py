from . import hr_job_setting
from . import hr_skils_job
from . import hr_job
from . import wizard
from . import parser
