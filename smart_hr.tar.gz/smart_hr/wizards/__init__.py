# -*- coding: utf-8 -*-

import hr_refuse_wizard
