# -*- coding: utf-8 -*-

from . import hr
from . import hr_payroll
from . import setting
from . import hr_deduction

