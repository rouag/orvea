# -*- coding: utf-8 -*-

from . import wizard_resume_holidays
