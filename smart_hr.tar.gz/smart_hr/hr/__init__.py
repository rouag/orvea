from . import hr_department
from . import hr_contract
from . import hr_employee
