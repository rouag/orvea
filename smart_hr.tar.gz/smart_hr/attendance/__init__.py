from . import hr_attendance
from . import hr_public_holiday
from . import hr_extra_hours
from . import hr_authorization
from . import hr_request_transfer
from . import wizard
from . import hr
from . import parser
